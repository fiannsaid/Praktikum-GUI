def kali(a,b):
  c = a*b
  return c
  z = kali (10,5)