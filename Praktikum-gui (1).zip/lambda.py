def maks(a,b):
  if a>b:
    return a
    else:
      return b
      maks(20,25)
      maks = lambda a,b: a if a>b else b maks (20,25)