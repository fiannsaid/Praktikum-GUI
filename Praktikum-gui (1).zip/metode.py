class Titit(object):
  def __init__(self, x=0, y=0):
    self.x = x
    self.y = t
    def pindah(self, x,y):
      self.x= x
      self.y = y
      def cetak(self):
        print'(%d,%d)' %(self.x,self.7))'
        t = Titik()
        t.cetak()
        t.pindah(5,10)
        t.cetak()