def cetakBonus(daftar=[]):
  def hitungBonus(gaji):
    if gaji < 500000:
      bonus = 0.05 * gaji
      elif 500000 <= gaji < 7500000:
        bonus =0.10 * gaji
        else:
          bonus = 0.15* gaji
          return bonus
          for nama, gaji in daftar:
            b = hitungBonus(gaji)
            print('%s\t%d\t%.2f' %(nama,gaji,b))
            data = [
              ('ucok',4000000),
              ('Budi',6000000),
              ('Wagiman',8000000)
            ]
            cetakBonus(data)
            hitungBonus(data)